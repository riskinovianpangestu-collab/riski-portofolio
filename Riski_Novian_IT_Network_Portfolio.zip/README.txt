# Riski Novian — IT & Network Portfolio

## Cara membuka
1. Extract ZIP.
2. Buka `index.html` di Chrome/Edge/Firefox.
3. Website langsung berjalan di HP atau laptop.

## Yang perlu diedit
Buka `index.html`, lalu ganti:
- `your.email@example.com`
- URL LinkedIn
- nomor WhatsApp pada link `wa.me`

Kamu juga bisa menambahkan foto proyek pada bagian Projects jika sudah punya dokumentasinya.

## Struktur
- index.html
- style.css
- script.js
